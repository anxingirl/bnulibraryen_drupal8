/**
 * @file
 * JavaScript behavior to remove destination from contextual links.
 */

(function ($) {

  'use strict';

  // Bind click event to all .contextual links which are
  // dynamically inserted via Ajax.
  // @see webform_contextual_links_view_alter()
  // @see Drupal.behaviors.contextual
  $(document).on('click', '.contextual', function() {
    $(this).find('a.webform-contextual').each(function() {
      this.href = this.href.split('?')[0];
    });
  });
  
})(jQuery);
