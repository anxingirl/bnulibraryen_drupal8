<?php

/**
 * @file
 * Hooks provided by the Custom Formatters module.
 */
